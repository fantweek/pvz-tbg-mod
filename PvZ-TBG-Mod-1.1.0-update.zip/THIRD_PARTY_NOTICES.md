# Third-party notices / Сторонние компоненты

PvZ TBG Mod включает исходный код следующих проектов.

## Dear ImGui

Каталог `third_party/imgui/` — копия нужных файлов [Dear ImGui](https://github.com/ocornut/imgui) (версия в `imgui.h`),
автор Omar Cornut и участники проекта. Лицензия MIT:

```
The MIT License (MIT)

Copyright (c) 2014-2026 Omar Cornut

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Игра

*Plants vs. Zombies* — торговая марка и собственность PopCap Games / Electronic Arts. Репозиторий **не содержит** файлов игры, графики,
звуков или кода игры и не связан с правообладателями. Для работы нужна ваша собственная копия игры.
